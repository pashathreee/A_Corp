// Packages
const express = require('express');
const jwt = require('jsonwebtoken');
var cookieParser = require('cookie-parser');
var escape = require('escape-html');
var serialize = require('node-serialize');

const app = express();
app.use(cookieParser())
app.use(express.static('public'))

app.get('/api', (req, res) => {
  res.json({
    message: 'Welcome to the A_CORP API'
  });
});

app.get('/api/admin', (req, res) => {

if (req.cookies.profile) {
   var str = new Buffer(req.cookies.profile, 'base64').toString();
   var obj = serialize.unserialize(str);
   if (obj.username) {
     res.json("Powered by NodeJS - Cookies Serialization - Last admin login: " + escape(obj.username));
   }
 } else {
    
     res.json("Unauthorize [Cookies Missing]");
 }


});

app.get('/admin', (req, res) => {
  res.json({
    message: 'Authorization: Bearer <token>'
  });
});


app.post('/admin', verifyToken, (req, res) => {  
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if(err) {
      res.send("Authorization: Bearer <token>  - Missing");
    } else {

       res.cookie('profile', "eyJ1c2VybmFtZSI6IkFsaSIsImNvdW50cnkiOiJQYWtpc3RhbiIsImNpdHkiOiJLYXJhY2hpIn0=", {
       maxAge: 900000,
       httpOnly: true
     });

 res.send(`




<!DOCTYPE html>
<html>
<head>
    <title>Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="Resources/favicon_io/apple-touch-icon.png"><link rel="icon" type="image/png" sizes="32x32" href="Resources/favicon_io/favicon-32x32.png"><link rel="icon" type="image/png" sizes="16x16" href="Resources/favicon_io/favicon-16x16.png">
    <link rel="manifest" href="Resources/favicon_io/site.webmanifest">

<style>

body {
    margin: 0;
    background-color: #e1f4f8
}

h1 {
    text-align:center;
    font-size: 60px;
    font-family: helvetica;
    padding-top: 20px;
    color: #343434;
    
}

p { 
    text-align:center;
    color: #343434;
    font-weight: normal;
    font-size: 20px;
    font-family: helvetica;
}

table, th, td {
border: 1px solid black;        /*For making border*/
padding:  5px;              /*For padding*/
/*uncomment for collapse but border spacing wont wrk*/
/*border-collapse: collapse;    /*For collasping border*/
}


table{
  border-spacing: 15px;         /*border space*/
}

table#t01 tr:nth-child(even) {
  background-color: #eee;
}
table#t01 tr:nth-child(odd) {
 background-color: #fff;
}
table#t01 th {
  background-color: black;
  color: white;
}

</style>

</head>
<body>

<h1>Welcome Admin</h1>
<p>Flag: doa3udq$uadj8!828*om9^</p>


`);


 
    }

  });
});


app.get('/api/user/3', (req, res) => {
  res.json({
    message: 'ali@email.com'
  });
});

app.get('/api/user/2', (req, res) => {
  res.json({
    message: 'umer@email.com'
  });
});

app.get('/api/user/1', (req, res) => {
    res.sendStatus(403);

});

app.get('/api/user/', (req, res) => {
  res.json({
    message: 'please provide user id'
  });
});

app.get('/api/user/*', (req, res) => {
  res.json({
    message: 'Invalid User ID'
  });
});

app.post('/api/user/1', (req, res) => {
  // User_1
  const user = {
    id: 1, 
    username: 'admin',
    email: 'admin@email.com'
  }

  jwt.sign({user}, 'secretkey', { expiresIn: '3h' }, (err, token) => {
    res.json({
      token
    });
  });
});


app.get('/api/auth/*', (req, res) => {
  res.json({
    message: 'Invalid Credentials'
  });
});

app.get('*',function(req,res){
 res.redirect('/index.html');
});

// FORMAT OF TOKEN
// Authorization: Bearer <access_token>

// Verify Token
function verifyToken(req, res, next) {
  // Get auth header value
  const bearerHeader = req.headers['authorization'];
  // Check if bearer is undefined
  if(typeof bearerHeader !== 'undefined') {
    // Split at the space
    const bearer = bearerHeader.split(' ');
    // Get token from array
    const bearerToken = bearer[1];
    // Set the token
    req.token = bearerToken;
    // Next middleware
    next();
  } else {
    // Forbidden
    // res.json("for own message")
    res.sendStatus(403);
  }

}

app.listen(8000, () => console.log('Server started on port 8000'));